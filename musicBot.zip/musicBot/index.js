const { Highrise, Events } = require('highrise.sdk.dev');
const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');

dotenv.config({ path: path.resolve(__dirname, '..', '.env') });
dotenv.config();

const RADIO_API_URL = process.env.RADIO_API_URL || process.env.RADIO_SERVER_URL || 'http://127.0.0.1:3000';
const RADIO_API_TOKEN = process.env.RADIO_API_TOKEN || process.env.API_TOKEN;
const SUPABASE_URL = process.env.SUPABASE_URL || '';
const SUPABASE_KEY = process.env.SUPABASE_KEY || '';
const RADIO_API_TIMEOUT_MS = Number(process.env.RADIO_API_TIMEOUT_MS || 10000);
const RADIO_PLAY_TIMEOUT_MS = Number(process.env.RADIO_PLAY_TIMEOUT_MS || 300000);
const RADIO_API_FALLBACKS = String(process.env.RADIO_API_URL_FALLBACKS || '').split(',').map((value) => value.trim()).filter(Boolean);
const MESSAGE_TEMPLATE_PATH = path.resolve(__dirname, '..', 'message.txt');
const PLAYLIST_PATH = path.resolve(__dirname, 'playlist.json');

function loadMessageTemplate() {
    try {
        return fs.readFileSync(MESSAGE_TEMPLATE_PATH, 'utf8');
    } catch {
        return '';
    }
}

const messageTemplateSource = loadMessageTemplate();

let playlist = [];
function loadPlaylist() {
    try {
        const txt = fs.readFileSync(PLAYLIST_PATH, 'utf8');
        const parsed = JSON.parse(txt);
        // assume top-level object with one key containing array
        if (Array.isArray(parsed)) playlist = parsed;
        else if (parsed && typeof parsed === 'object') {
            const first = Object.values(parsed)[0];
            if (Array.isArray(first)) playlist = first;
        }
    } catch (e) {
        playlist = [];
    }
}
loadPlaylist();

function normalizeApiBaseUrl(value) {
    const raw = String(value || '').trim().replace(/\/$/, '');
    if (!raw) {
        return '';
    }

    const cleaned = raw.replace(/^https?:\/\/(https?:\/\/)+/i, (match) => match.replace(/^(https?:\/\/)+/i, ''));
    const withoutDoublePrefix = cleaned.replace(/^https?:\/\//i, (prefix) => prefix.toLowerCase());

    try {
        const parsed = new URL(withoutDoublePrefix.startsWith('http://') || withoutDoublePrefix.startsWith('https://') ? withoutDoublePrefix : `http://${withoutDoublePrefix}`);
        return `${parsed.protocol}//${parsed.host}`;
    } catch {
        return withoutDoublePrefix;
    }
}

const hasExplicitRadioUrl = Boolean(String(process.env.RADIO_API_URL || process.env.RADIO_SERVER_URL || '').trim());
const RADIO_API_BASE_URLS = Array.from(new Set([
    RADIO_API_URL,
    ...(hasExplicitRadioUrl ? [] : ['http://127.0.0.1:3000', 'http://localhost:3000']),
    ...RADIO_API_FALLBACKS,
].map(normalizeApiBaseUrl).filter(Boolean)));

const bot = new Highrise({
    Events: [Events.Messages],
    AutoFetchMessages: true,
    Cache: true,
});

const token = process.env.HIGHRISE_BOT_TOKEN;
const roomId = process.env.HIGHRISE_ROOM_ID;

async function fetchJson(url, opts = {}, timeoutMs = RADIO_API_TIMEOUT_MS) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(new Error(`Request timed out after ${timeoutMs}ms`)), timeoutMs);

    try {
        const res = await fetch(url, { ...opts, signal: controller.signal });
        const text = await res.text();
        try { return { ok: res.ok, status: res.status, json: JSON.parse(text) }; } catch { return { ok: res.ok, status: res.status, text }; }
    } finally {
        clearTimeout(timeout);
    }
}

function joinUrl(baseUrl, path) {
    return `${normalizeApiBaseUrl(baseUrl)}${path.startsWith('/') ? path : `/${path}`}`;
}

function getUsername(user) {
    return String(user?.username || user?.name || user?.displayName || 'User').trim();
}

function formatAtUsername(user) {
    return `@${getUsername(user)}`;
}

function formatDuration(seconds) {
    const totalSeconds = Number(seconds);
    if (!Number.isFinite(totalSeconds) || totalSeconds < 0) {
        return '--:--';
    }

    const minutes = Math.floor(totalSeconds / 60);
    const remainingSeconds = Math.floor(totalSeconds % 60);
    return `${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
}

function displayRequester(track, fallback = 'system') {
    const raw = String(
        track?.requesterUsername ||
        track?.requestedBy ||
        track?.requesterDisplayName ||
        track?.requesterName ||
        fallback ||
        'system'
    ).replace(/^@/, '');
    const botUsername = getUsername(bot.info.user || {});
    if (raw && botUsername && raw.toLowerCase() === botUsername.toLowerCase()) {
        return '@Hind.DJ';
    }
    return `@${raw}`;
}

function truncateTitle(title, max = 30) {
    const s = String(title || '').trim();
    if (s.length <= max) return s;
    return `${s.slice(0, max)}...`;
}
function buildSearchMessage(query) {
    return `<#FFD700>🔍 SEARCHING SONG\n<#EDEDED>Looking for: ${String(query || '').trim()}\n`;
}

function buildQueueAckMessage(track, queuePosition) {
    return `<#FFD700>🎯 ADDED TO QUEUE\n<#EDEDED>Position: #${queuePosition || 1}\nTitle: ${truncateTitle(track?.title || 'Unknown')}\nSinger: ${track?.uploader || 'Unknown'}\nDuration: ${formatDuration(track?.duration)}\nRequested By: ${displayRequester(track)}\n`;
}

function buildNowPlayingMessage(nowPlaying, _, __, requesterFallback) {
    // Only send the NOW PLAYING block as specified by the user
    return `\n<#FFD700>🎵 NOW PLAYING\n\n<#00FF7F>Title: ${truncateTitle(nowPlaying?.title || 'Unknown', 50)}\nSinger: ${nowPlaying?.uploader || 'Unknown'}\nDuration: ${formatDuration(nowPlaying?.position || 0)}/${formatDuration(nowPlaying?.duration)}\nRequested By: ${displayRequester(nowPlaying, requesterFallback)}`;
}

function buildNextMessage(nextSong) {
    return `\n<#00CED1>⏭️ NEXT SONG\n\n<#00FF7F>Title: ${truncateTitle(nextSong?.title || 'Unknown', 50)}\nSinger:${nextSong?.uploader || 'Unknown'}\nDuration: ${formatDuration(nextSong?.duration)}\nRequested By: ${displayRequester(nextSong)}`;
}

function buildQueueMessage(queue) {
    const queueLines = Array.isArray(queue) && queue.length > 0
        ? queue.slice(0, 3).map((song, index) => `${index + 1}. ${song.title || song.id || 'Unknown'}`)
        : ['1. No queued songs.', '2. No queued songs.', '3. No queued songs.'];

    return `<#FFD700>📜 QUEUE\n<#EDEDED>${queueLines.join(' | ')}\n`;
}

function buildHelpMessage() {
    return [
        '<#FFD700>🎵 MUSIC BOT HELP',
        '',
        '<#EDEDED>-play song_name   Queue a song',
        '-skip  Skip the current song',
        '-queue Show the queue',
        '-np    Show now playing',
        '-next  Show next song',
        '-help  Show this help',
    ].join('\n');
}

async function isVerified(userId) {
    if (!SUPABASE_URL || !SUPABASE_KEY) return true; // allow if not configured
    try {
        const url = `${SUPABASE_URL.replace(/\/$/, '')}/rest/v1/verified_users?user_id=eq.${encodeURIComponent(userId)}&select=*`;
        const res = await fetch(url, { headers: { apikey: SUPABASE_KEY, Authorization: `Bearer ${SUPABASE_KEY}` } });
        if (!res.ok) return false;
        const data = await res.json();
        return Array.isArray(data) && data.length > 0;
    } catch (e) {
        return false;
    }
}

async function postToRadio(path, body = {}, timeoutMs = RADIO_API_TIMEOUT_MS) {
    let lastError = null;

    for (const baseUrl of RADIO_API_BASE_URLS) {
        const url = joinUrl(baseUrl, path);
        try {
            return await fetchJson(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${RADIO_API_TOKEN}`,
                },
                body: JSON.stringify(body),
            }, timeoutMs);
        } catch (error) {
            lastError = new Error(`POST ${url} failed: ${error.message || String(error)}`);
        }
    }

    throw new Error(`Failed to reach radio API for ${path}. Tried: ${RADIO_API_BASE_URLS.join(', ')}. Last error: ${lastError ? lastError.message : 'unknown network error'}`);
}

async function getFromRadio(path, timeoutMs = RADIO_API_TIMEOUT_MS) {
    let lastError = null;

    for (const baseUrl of RADIO_API_BASE_URLS) {
        const url = joinUrl(baseUrl, path);
        try {
            return await fetchJson(url, { headers: { Authorization: `Bearer ${RADIO_API_TOKEN}` } }, timeoutMs);
        } catch (error) {
            lastError = new Error(`GET ${url} failed: ${error.message || String(error)}`);
        }
    }

    throw new Error(`Failed to reach radio API for ${path}. Tried: ${RADIO_API_BASE_URLS.join(', ')}. Last error: ${lastError ? lastError.message : 'unknown network error'}`);
}

function isPromotionCommand(text) {
    const normalized = String(text || '').trim().toLowerCase();
    return normalized === '-promote' || normalized === 'promote' || normalized === '-promo' || normalized === 'promo' || normalized === 'promotion' || normalized === 'promotion.mp3';
}

async function requestPromotion(user) {
    const res = await postToRadio('/promote', {}, RADIO_PLAY_TIMEOUT_MS);
    if (!res.ok) {
        await bot.whisper.send(user.id, `Promotion request failed: ${res.status}`);
        return false;
    }

    await bot.whisper.send(user.id, 'Promotion queued. The radio will play the promotion audio next.');
    return true;
}

async function sendPlaybackSnapshot(user, requesterFallback) {
    const nowRes = await getFromRadio('/now-playing');
    if (!nowRes.ok) {
        await bot.whisper.send(user.id, 'Failed to fetch now-playing status');
        return;
    }

    const queueRes = await getFromRadio('/queue');
    const queue = queueRes.ok ? (queueRes.json.queue || []) : [];
    const nowPlaying = nowRes.json.nowPlaying || nowRes.json.radio?.currentTrack;
    const nextSong = nowRes.json.preparedNext || nowRes.json.radio?.preparedNextTrack;

    if (!nowPlaying) {
        await bot.whisper.send(user.id, 'Nothing is playing right now.');
        return;
    }

    await bot.message.send(buildNowPlayingMessage(nowPlaying, nextSong, queue, requesterFallback));
}
let homePos = {
        x: 16.5,
        y: 15.75,
        z: 3.5,
        facing: "FrontRight"
}
const botId = bot.info.user.id;
bot.on('ready', () => {
    bot.message.send('<#FFD700>Your DJ is ready\n<#EDEDED>Use -play, -skip, -queue, -np, -next, -promote, -help');
    bot.player.teleport(botId, homePos.x, homePos.y, homePos.z, homePos.facing);
    startAutopilot().catch((e) => console.warn('Autopilot failed:', e && e.message));
});

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

function pickRandomPlaylistEntry() {
    if (!Array.isArray(playlist) || playlist.length === 0) return null;
    const idx = Math.floor(Math.random() * playlist.length);
    return playlist[idx];
}

async function sendBotPlayRequest(input) {
    const botUsername = getUsername(bot.info.user || {});
    const requesterDisplayName = bot.info.user?.displayName || bot.info.user?.name || 'Bot';
    try {
        const ack = await postToRadio('/play', {
            url: input,
            requesterId: bot.info.user?.id || null,
            requesterName: bot.info.user?.name || requesterDisplayName,
            requesterDisplayName,
            requesterUsername: botUsername,
        }, RADIO_PLAY_TIMEOUT_MS);
        return ack;
    } catch (e) {
        console.warn('Bot play request failed:', e && e.message);
        return null;
    }
}

function isUserQueuePresent(queue, botUsername) {
    if (!Array.isArray(queue)) return false;
    return queue.some((t) => {
        const req = String(t?.requesterUsername || t?.requestedBy || '').replace(/^@/, '').trim();
        if (!req) return true; // unknown requester -> treat as user
        return req.toLowerCase() !== (botUsername || '').toLowerCase();
    });
}

function isFallbackTrack(track) {
    if (!track) return false;
    const id = String(track.id || '').toLowerCase();
    const filePath = String(track.filePath || '').toLowerCase();
    const title = String(track.title || '').toLowerCase();
    const requestedBy = String(track.requestedBy || track.requesterUsername || track.requesterName || '').toLowerCase();
    if (!id && !filePath && !title) return false;
    if (id === 'fallback') return true;
    if (title === 'fallback audio') return true;
    if (filePath.endsWith('fallback.mp3') || filePath.includes('/fallback') || filePath.includes('fallback.mp3')) return true;
    if (title.includes('fallback') || title.includes('silence') || title.includes('default track')) return true;
    if (requestedBy === '@system' && title.includes('fallback')) return true;
    return false;
}

function isBotQueuedTrack(track, botUsername) {
    const req = String(track?.requesterUsername || track?.requestedBy || track?.requesterName || '').replace(/^@/, '').trim();
    return Boolean(req) && req.toLowerCase() === String(botUsername || '').toLowerCase();
}

function hasBotQueuedTrack(queue, botUsername) {
    return Array.isArray(queue) && queue.some((track) => isBotQueuedTrack(track, botUsername));
}

function getTrackPositionSeconds(track) {
    const candidates = [track?.position, track?.currentPosition, track?.elapsed, track?.playedSeconds, track?.progressSeconds];
    for (const value of candidates) {
        const num = Number(value);
        if (Number.isFinite(num) && num >= 0) return num;
    }
    return null;
}

function getTrackDurationSeconds(track) {
    const num = Number(track?.duration);
    return Number.isFinite(num) && num >= 0 ? num : null;
}

function getTrackRemainingSeconds(track) {
    const duration = getTrackDurationSeconds(track);
    const position = getTrackPositionSeconds(track);
    if (duration == null || position == null) return null;
    return Math.max(duration - position, 0);
}

async function waitWithUserChecks(ms, botUsername, intervalMs = 5000) {
    const start = Date.now();
    while (Date.now() - start < ms) {
        const qCheck = await getFromRadio('/queue');
        const q = qCheck.ok ? (qCheck.json.queue || []) : [];
        if (isUserQueuePresent(q, botUsername)) return 'user-queue';
        const remaining = ms - (Date.now() - start);
        if (remaining <= 0) break;
        await sleep(Math.min(intervalMs, remaining));
    }
    return 'done';
}

async function startAutopilot() {
    const botUsername = getUsername(bot.info.user || {});
    while (true) {
        try {
            const queueRes = await getFromRadio('/queue');
            const nowRes = await getFromRadio('/now-playing');
            const queue = queueRes.ok ? (queueRes.json.queue || []) : [];
            const nowPlaying = nowRes.ok ? (nowRes.json.nowPlaying || nowRes.json.radio?.currentTrack) : null;
            const userQueuePresent = isUserQueuePresent(queue, botUsername);
            const botQueuePresent = hasBotQueuedTrack(queue, botUsername);
            const activeTrack = isFallbackTrack(nowPlaying) ? null : nowPlaying;

            // If there are user requests in queue, let them take priority.
            if (userQueuePresent) {
                await sleep(8000);
                continue;
            }

            // Case 1: bot just started and nothing real is on stream.
            // Treat Fallback Audio as no stream and replace it immediately.
            if (!activeTrack) {
                if (!botQueuePresent) {
                    const pick = pickRandomPlaylistEntry();
                    if (pick) {
                        await sendBotPlayRequest(pick);
                        if (nowPlaying && isFallbackTrack(nowPlaying)) {
                            await postToRadio('/skip', { count: 1 });
                        }
                    }
                }
                await sleep(8000);
                continue;
            }

            const remainingSeconds = getTrackRemainingSeconds(activeTrack);

            // Case 2 and 3: a real song is already on stream.
            // If the bot already queued one of its own tracks, wait.
            if (botQueuePresent) {
                await sleep(8000);
                continue;
            }

            if (remainingSeconds == null) {
                await sleep(10000);
                continue;
            }

            if (remainingSeconds > 20) {
                const waitMs = Math.max((remainingSeconds - 20) * 1000, 5000);
                const waitResult = await waitWithUserChecks(waitMs, botUsername);
                if (waitResult === 'user-queue') {
                    await sleep(2000);
                }
                continue;
            }

            // Last 20 seconds: if no user request arrived and no bot track is already queued, add one playlist song.
            const freshQueueRes = await getFromRadio('/queue');
            const freshQueue = freshQueueRes.ok ? (freshQueueRes.json.queue || []) : [];
            if (isUserQueuePresent(freshQueue, botUsername) || hasBotQueuedTrack(freshQueue, botUsername)) {
                await sleep(5000);
                continue;
            }

            const pick = pickRandomPlaylistEntry();
            if (!pick) {
                await sleep(10000);
                continue;
            }

            const ack = await sendBotPlayRequest(pick);
            if (!ack || !ack.ok) {
                await sleep(10000);
                continue;
            }

            await sleep(5000);
        } catch (e) {
            console.warn('Autopilot loop error:', e && e.message);
            await sleep(10000);
        }
    }
}

bot.on('whisperCreate', async(user, message)=>{
    if (isPromotionCommand(message)) {
        try {
            await requestPromotion(user);
        } catch (error) {
            await bot.whisper.send(user.id, `Promotion request error: ${error.message || String(error)}`);
        }
    }
});

bot.on('chatCreate', async (user, message) => {
    try {
        if (!message || typeof message !== 'string') return;
        if (!message.startsWith('-')) return;
        const text = message.slice(1).trim();
        if (!text) return;
        const args = text.split(/\s+/);
        const cmd = args.shift().toLowerCase();

        if (isPromotionCommand(cmd) || isPromotionCommand(text)) {
            try {
                await requestPromotion(user);
            } catch (error) {
                await bot.message.send('Music bot error: ' + (error.message || String(error)));
            }
            return;
        }

        const verified = await isVerified(user.id || user.userId || user);
        if (!verified) {
            await bot.whisper.send(user.id, 'You are not verified to use the music bot. Please DM @Hind.MANAGER a "Hi" to get verified.');
            return;
        }

        if (cmd === 'play') {
            const input = args.join(' ').trim();
            if (!input) { await bot.whisper.send(user.id, 'Usage: -play <url or search query>'); return; }
            await bot.whisper.send(user.id, buildSearchMessage(input));
            const requesterDisplayName = user.displayName || user.name || 'User';
            const ack = await postToRadio('/play', {
                url: input,
                requesterId: user.id || user.userId || null,
                requesterName: user.name || requesterDisplayName,
                requesterDisplayName,
                requesterUsername: getUsername(user),
            }, RADIO_PLAY_TIMEOUT_MS);
            if (!ack.ok) {
                await bot.message.send(`Failed to add track: ${ack.status}`);
                return;
            }
            const track = ack.json.track || ack.json;
            await bot.whisper.send(user.id, buildQueueAckMessage(track, ack.json.queueLength || 1));

            const targetId = track.id;
            const start = Date.now();
            const timeoutMs = 120000;
            while (Date.now() - start < timeoutMs) {
                const now = await getFromRadio('/now-playing');
                if (now.ok && now.json && now.json.nowPlaying && now.json.nowPlaying.id === targetId) {
                    await sendPlaybackSnapshot(user, getUsername(user));
                    break;
                }
                await new Promise((r) => setTimeout(r, 2000));
            }
            return;
        }

        if (cmd === 'help') {
            await bot.whisper.send(user.id, buildHelpMessage());
            return;
        }

        if (cmd === 'skip') {
            const res = await postToRadio('/skip', { count: 1 });
            if (res.ok) {
                await bot.whisper.send(user.id, '⏭️ Skip requested. Updating the current playback snapshot...');
                await sendPlaybackSnapshot(user, getUsername(user));
            }
            else await bot.message.send('Skip request failed');
            return;
        }

        if (cmd === 'queue') {
            const res = await getFromRadio('/queue');
            if (!res.ok) { await bot.message.send('Failed to fetch queue'); return; }
            const q = res.json.queue || [];
            await bot.whisper.send(user.id, buildQueueMessage(q));
            return;
        }

        if (cmd === 'np') {
            const res = await getFromRadio('/now-playing');
            if (!res.ok) { await bot.message.send('Failed to fetch now-playing'); return; }
            const now = res.json.nowPlaying;
            if (!now) { await bot.message.send('Nothing is playing'); return; }
            const queueRes = await getFromRadio('/queue');
            const queue = queueRes.ok ? (queueRes.json.queue || []) : [];
            const nextSong = res.json.preparedNext || res.json.radio?.preparedNextTrack;
            await bot.whisper.send(user.id, buildNowPlayingMessage(now, nextSong, queue, getUsername(user)));
            return;
        }

        if (cmd === 'next') {
            const res = await getFromRadio('/now-playing');
            if (!res.ok) { await bot.message.send('Failed to fetch next track'); return; }
            const next = res.json.preparedNext || res.json.radio?.preparedNextTrack;
            if (!next) { await bot.whisper.send(user.id, 'No next track.'); return; }
            await bot.whisper.send(user.id, buildNextMessage(next));
            return;
        }

        // unknown command
        await bot.whisper.send(user.id, 'Unknown command. Available: play, skip, queue, np, next, promote, help');
    } catch (err) {
        try { await bot.message.send('Music bot error: ' + (err.message || String(err))); } catch (e) {}
    }
});

if (!token || !roomId) {
    console.error('Missing HIGHRISE_BOT_TOKEN or HIGHRISE_ROOM_ID. The music bot cannot connect until both are set.');
} else {
    if (!messageTemplateSource.trim()) {
        console.warn(`message.txt was not found at ${MESSAGE_TEMPLATE_PATH}; using built-in message layouts.`);
    }
    if (RADIO_API_BASE_URLS[0] !== normalizeApiBaseUrl(RADIO_API_URL)) {
        console.warn(`Normalized RADIO_API_URL from "${RADIO_API_URL}" to "${RADIO_API_BASE_URLS[0]}"`);
    }
    console.log(`Music bot using radio API: ${RADIO_API_BASE_URLS[0]}`);
    if (hasExplicitRadioUrl && RADIO_API_BASE_URLS.length === 1) {
        console.log('No localhost fallback is enabled because an explicit RADIO_API_URL was set.');
    }
    bot.login(token, roomId);
}